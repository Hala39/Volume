export class File {
    appUserId: string;
    url: string;
}