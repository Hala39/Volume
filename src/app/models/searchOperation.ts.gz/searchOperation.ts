export class SearchOperation {
    id?: number;
    keyword: string;
    date?: Date;
}