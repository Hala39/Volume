export class FbLogin {
    email: string;
    name: string;
    authToken: string;
    photoUrl: string;
}