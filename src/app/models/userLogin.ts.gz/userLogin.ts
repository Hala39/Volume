export class UserLogin {
    email: string;
    password: string;
}