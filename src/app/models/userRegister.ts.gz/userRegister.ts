export interface UserRegister {
    email: string;
    displayName: string;
    password: string;
}