export interface UserCard {
    id: string;
    profilePhotoUrl?: string;
    displayName: string;
    userName?: string;

    token?: string;
} 